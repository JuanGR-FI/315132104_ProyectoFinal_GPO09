You must Extract this folder to have the textures to work with.
By: SeinosCollazo